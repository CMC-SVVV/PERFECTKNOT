 <b>1.</b> <b> <p style = "color:Tomato;"> 	There is only one happiness in "life" to loveand to be loved .<br>
 	 The couples that are meant to be are the ones who go through  <br>
	everything  that is meant to fear them apart and come out even stronger !!!!  </p> </b>

<b>2.</b> <b> <p style = "color:HotPink;">
Someone who really loves you sees what a mess you <br>
can be, how moody you can get how hard you are to handle,<br>
but still wants you in there lives! </p></b>  


<b>3.</b> <b> <p style = " color:Black;">
	when there is a strong bond between two people universe also <br>
	     tries  to search a way to bring them together no matter what happens <br>
	you cannot stop anyone to think of their loved ones  </p></b>

<b>4.</b> <b> <p style = " color:DarkOrchid;">
	love is not written  on paper , for paper can be erased<br>  
	nor is it etched  on stone , for stone can be broken .<br>
	but is inscribed on a heart and there<br>
	shall remain forever </p></b>

<b>5.</b> <b> <p style = " color palegreen ;">
     The deeper  scares , the more room  <br>
      there is to fill them up with love <br>
     dont hate your scares , appreciate their depth<br> 
     </p></b>    