<iframe width="560" height="315" src="https://www.youtube.com/embed/F-_lAdy19DI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d14721.919849468379!2d75.84196195!3d22.710395199999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1570444172548!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
<iframe src="https://www.google.com" allowfullscreen=""></iframe>


<iframe src="http://svvv.edu.in/" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
<iframe width="900" height="506" src="https://www.youtube.com/embed/HR8-Z5KNYLU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>