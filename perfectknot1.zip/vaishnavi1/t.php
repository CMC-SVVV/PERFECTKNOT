<table align="center" border="2">
<thead>
 
    <th>&nbsp;</th>
    <th>&nbsp;</th>
    <th rowspan="5">&nbsp;!</th>


  <tr>
    <td>Vaibhav</td>
    
    <td rowspan="0">$100</td>
  </tr>
   <tr>
    <td>18</td>
   
  </tr>

  
  
  <tr>
  
    <td>gen</td>
      </tr>
	   <tr>
    <td>indore</td>
   
  </tr>

  <tr>
    <td>345678</td>
   
  </tr>

  
</tbody>
</table><br>
<table border="2">
<thead>
 
    <th>&nbsp;</th>
    <th>&nbsp;</th>
    <th rowspan="5">&nbsp;!</th>


  <tr>
    <td>Vaibhav</td>
    
    <td rowspan="0">$100</td>
  </tr>
   <tr>
    <td>18</td>
   
  </tr>

  
  
  <tr>
  
    <td>gen</td>
      </tr>
	   <tr>
    <td>indore</td>
   
  </tr>

  <tr>
    <td>345678</td>
   
  </tr>

  
</tbody>
</table><table border="2">
<thead>
 
    <th>&nbsp;</th>
    <th>&nbsp;</th>
    <th rowspan="5">&nbsp;!</th>


  <tr>
    <td>Vaibhav</td>
    
    <td rowspan="0">$100</td>
  </tr>
   <tr>
    <td>18</td>
   
  </tr>

  
  
  <tr>
  
    <td>gen</td>
      </tr>
	   <tr>
    <td>indore</td>
   
  </tr>

  <tr>
    <td>345678</td>
   
  </tr>

  
</tbody>
</table><table border="2">
<thead>
 
    <th>&nbsp;</th>
    <th>&nbsp;</th>
    <th rowspan="5">&nbsp;!</th>


  <tr>
    <td>Vaibhav</td>
    
    <td rowspan="0">$100</td>
  </tr>
   <tr>
    <td>18</td>
   
  </tr>

  
  
  <tr>
  
    <td>gen</td>
      </tr>
	   <tr>
    <td>indore</td>
   
  </tr>

  <tr>
    <td>345678</td>
   
  </tr>

  
</tbody>
</table>